# scrabble
Preliminary Scrabble Game - 1 source code file(s) are part of this project:

	-> Scrabble.java

Additional files are included. 


	-> Three directories are included. tiles contains images for letter tiles
	images contains images for the special icons on the board
	data contains the text file for the dictionary.
	
To compile this program, execute:

$ javac Scrabble.java

To run this program, execute:

$ java Scrabble

To play the game simply click on any space in the board, input a word into the text field, 
choose a direction and see the word get placed on the board.

This game is NOT complete! There are several bugs that do not follow the rules of Scrabble.

*Known bugs*:
	A move after the first move in the center of the board will always be valid.
	Words can be put directly next to each other or on top of each other.

About this program: 
During my first semester of college I was tasked with creating a Scrabble game. We only needed to
get the input on the board but since then I implemented checks for valid moves and valid words.
The game is still unfinished but I work on it when I have free time.
